# app/models/schemas.py
from pydantic import BaseModel, Field
from typing import List

class StartGameRequest(BaseModel):
    player_count: int = Field(..., ge=2, le=4)

class ActionRequest(BaseModel):
    player_id: str
    number: int
    action: str = Field(..., pattern="^(add|subtract)$")

class MoneyManagementRequest(BaseModel):
    table: int = Field(..., ge=0)
    chewe: int = Field(..., ge=0)
    kotariwe: int = Field(..., ge=0)
    deposits: List[int]
