# app/models/game.py
from typing import List, Optional

class Game:
    def __init__(self, player_count: int):
        self.player_count = player_count
        self.valid_numbers = list(range(3, 16))
        self.used_numbers = []
        self.game_over = False

        if player_count == 2:
            self.players = {
                "P1": {"history": [], "total_score": 0},
                "P2": {"history": [], "total_score": 0},
            }
        else:
            self.players = [
                {"id": f"P{i+1}", "score": 0} for i in range(player_count)
            ]

    def display_remaining_numbers(self) -> List[int]:
        return [n for n in self.valid_numbers if n not in self.used_numbers]

    def add_score(self, player_id: str, number: int):
        if self.game_over:
            raise ValueError("Game is already over")
        if number not in self.valid_numbers or number in self.used_numbers:
            raise ValueError("Invalid or already used number")

        pid = player_id.upper()
        if self.player_count == 2:
            self.players[pid]["history"].append(f"+{number}")
            self.players[pid]["total_score"] += number
        else:
            player = next(p for p in self.players if p["id"] == pid)
            player["score"] += 6 if number == 3 else number

        self.used_numbers.append(number)

    def subtract_score(self, player_id: str, number: int):
        pid = player_id.upper()
        if self.player_count == 2:
            other = "P1" if pid == "P2" else "P2"
            self.players[other]["total_score"] += number
        else:
            player = next(p for p in self.players if p["id"] == pid)
            player["score"] -= 6 if number == 3 else number

    def check_winner(self) -> Optional[str]:
        remaining_sum = sum(self.display_remaining_numbers())
        self.game_over = not self.display_remaining_numbers()
        if self.player_count == 2:
            return max(self.players, key=lambda p: self.players[p]["total_score"])
        return max(self.players, key=lambda p: p["score"])["id"]

    def get_status(self):
        return {
            "players": self.players,
            "remaining_numbers": self.display_remaining_numbers(),
            "used_numbers": self.used_numbers,
            "game_over": self.game_over
        }
