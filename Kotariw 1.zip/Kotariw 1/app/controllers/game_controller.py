# app/controllers/game_controller.py
from fastapi import APIRouter, HTTPException
from app.models.game import Game
from app.models.schemas import StartGameRequest, ActionRequest

router = APIRouter()
game_state = None

def ensure_game():
    if not game_state:
        raise HTTPException(status_code=400, detail="No game in progress")

@router.post("/start")
def start_game(req: StartGameRequest):
    global game_state
    game_state = Game(req.player_count)
    return game_state.get_status()

@router.post("/action")
def game_action(req: ActionRequest):
    ensure_game()
    if req.action == "add":
        game_state.add_score(req.player_id, req.number)
    else:
        game_state.subtract_score(req.player_id, req.number)
    winner = game_state.check_winner()
    return {"status": game_state.get_status(), "winner": winner}

@router.get("/status")
def status():
    ensure_game()
    return game_state.get_status()
