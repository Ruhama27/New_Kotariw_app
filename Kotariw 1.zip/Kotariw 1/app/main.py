from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from app.controllers.game_controller import router

app = FastAPI(title="Score Game API")

# API routes
app.include_router(router)

# Static files
app.mount(
    "/static",
    StaticFiles(directory="app/views/static"),
    name="static"
)

# Root route (HOME PAGE)
@app.get("/")
def read_index():
    return FileResponse("app/views/static/index.html")
